import { samplePhrases } from "./prompts/movie-critic";
// import { samplePhrases } from "./prompts/tour-guide";

export const appConfig = {
  historyLength: 8,
  samplePhrases,
};
